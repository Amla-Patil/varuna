# Varuna — Underwater Sonar Object Detection (Desktop App)

SIH 2026 — PySide6 desktop UI integrated with a trained YOLO11s sonar
detection pipeline (NLM preprocessing → YOLO11s detection → annotated
results).

## Project layout

```
varuna/
├── app/                 PySide6 desktop UI (MarineVision)
│   ├── main.py          Entry point
│   ├── marine_app.py    Main window, pages, and detection integration
│   └── splash.py        Splash screen
├── inference/            Inference pipeline
│   ├── detector.py       Ultralytics YOLO wrapper
│   ├── inference_pipeline.py  End-to-end pipeline (preprocess → detect → structure results)
│   └── visualization.py  Draws bounding boxes / labels on the sonar image
├── preprocessing/
│   └── nlm_preprocessing.py  Non-Local Means denoising (matches training preprocessing)
├── models/
│   └── yolo11s_baseline_640_best.pt  Trained weights
├── config/
│   └── classes.json      Class ID → name mapping
└── requirements.txt
```

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate        # Windows
# source .venv/bin/activate   # macOS/Linux

pip install -r requirements.txt
```

## Run

```bash
cd app
python main.py
```

## Using the app

1. Open the **Detection** page from the sidebar.
2. Click **Browse** and select a sonar image (PNG/JPG/JPEG/BMP/TIF/TIFF).
3. Set a confidence threshold (0–1, e.g. `0.50`).
4. Click **Start Analysis**. Inference runs on a background thread so the UI
   stays responsive.
5. Results appear as an annotated overlay image plus a per-object summary
   (class + confidence). Full results are also saved as JSON under
   `results/<image_name>_detection.json`, with the overlay saved alongside
   it as `results/<image_name>_overlay.png`.

The trained model is loaded once and cached for the lifetime of the app, so
the **first** analysis after launch will be a bit slower (model load) —
every run after that is fast. A GPU is used automatically if one is
available (via CUDA); otherwise inference runs on CPU.

## Detected classes

| ID | Class |
|----|-------|
| 0  | crab_pot |
| 1  | submarine_pipeline |
| 2  | shipwreck |
| 3  | ghost_net |
| 4  | mine_cylinder |

## Notes

- Preprocessing (NLM denoising) is applied identically to what was used
  during training, so detection quality should match evaluation results.
- CSV/mission-file selection is present in the file picker for future
  mission-log workflows, but current detection only supports image inputs.
